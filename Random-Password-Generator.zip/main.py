import math
import random

alpha = "abcdefghijklmnopqrstuvwxyz"
num = "0123456789"
special = "@$*"

# pass_len=random.randint(8,13)  #without User INput
pass_len = int(input("Enter Your Password Length "))

# length of password by 50-30-20 formula
alpha_len = pass_len//2
num_len = pass_len//3
special_len = pass_len//5

password = []

def generate_pass(length, array, is_alpha=False):
  for _ in range(length):
      character = random.choice(array)
      if is_alpha and random.choice([True, False]):
          character = character.upper()
      password.append(character)

# alpha password
generate_pass(alpha_len, alpha, True)
# numeric password
generate_pass(num_len, num)
# special Character password
generate_pass(special_len, special)
# suffle the generated password list
random.shuffle(password)
# convert List To string
gen_password = ""
for i in password:
    gen_password = gen_password + str(i)
print(gen_password)